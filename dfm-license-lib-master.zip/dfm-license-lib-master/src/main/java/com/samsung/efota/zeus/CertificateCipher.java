package com.samsung.efota.zeus;

import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

public class CertificateCipher {

    private PublicKey publicKey;
    private PrivateKey privateKey;

    public CertificateCipher(String base64PublicKey, String base64PrivateKey) {
        this.publicKey = getPublicKey(base64PublicKey);
        this.privateKey = getPrivateKey(base64PrivateKey);
    }

    private static PublicKey getPublicKey(String base64PublicKey) throws IllegalArgumentException {
        if (base64PublicKey == null) {
            return null;
        }

        PublicKey publicKey = null;
        try {
            X509EncodedKeySpec keySpec =
                    new X509EncodedKeySpec(
                            Base64.getDecoder()
                                    .decode(base64PublicKey.getBytes(StandardCharsets.UTF_8)));
            KeyFactory keyFactory = KeyFactory.getInstance("RSA");
            publicKey = keyFactory.generatePublic(keySpec);
            return publicKey;
        } catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new IllegalArgumentException("Get PublicKey has a problem", e);
        }
    }

    private static PrivateKey getPrivateKey(String base64PrivateKey)
            throws IllegalArgumentException {
        if (base64PrivateKey == null) {
            return null;
        }

        PrivateKey privateKey = null;
        PKCS8EncodedKeySpec keySpec =
                new PKCS8EncodedKeySpec(
                        Base64.getDecoder()
                                .decode(base64PrivateKey.getBytes(StandardCharsets.UTF_8)));
        KeyFactory keyFactory = null;
        try {
            keyFactory = KeyFactory.getInstance("RSA");
        } catch (NoSuchAlgorithmException e) {
            throw new IllegalArgumentException("NoSuchAlgorithmException in getPrivateKey", e);
        }

        try {
            privateKey = keyFactory.generatePrivate(keySpec);
        } catch (InvalidKeySpecException e) {
            throw new IllegalArgumentException("InvalidKeySpecException in getPrivateKey", e);
        }
        return privateKey;
    }

    public byte[] sign(byte[] headerBytes, byte[] payloadBytes)
            throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        final Signature s = Signature.getInstance("SHA256withRSA");
        s.initSign(privateKey);
        s.update(headerBytes);
        s.update(payloadBytes);
        return s.sign();
    }

    public boolean verify(byte[] headerBytes, byte[] payloadBytes, byte[] signatureBytes)
            throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        final Signature s = Signature.getInstance("SHA256withRSA");
        s.initVerify(publicKey);
        s.update(headerBytes);
        s.update(payloadBytes);
        return s.verify(signatureBytes);
    }
}
