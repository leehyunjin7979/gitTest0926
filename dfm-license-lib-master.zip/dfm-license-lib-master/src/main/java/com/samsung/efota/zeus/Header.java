package com.samsung.efota.zeus;

import java.util.Objects;
import java.util.StringJoiner;

public class Header {

    private String version;
    private Long timestamp;

    public String getVersion() {
        return version;
    }

    public Long getTimestamp() {
        return timestamp;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Header)) return false;
        Header header = (Header) o;
        return Objects.equals(version, header.version)
                && Objects.equals(timestamp, header.timestamp);
    }

    @Override
    public int hashCode() {
        return Objects.hash(version, timestamp);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", Header.class.getSimpleName() + "[", "]")
                .add("version='" + version + "'")
                .add("timestamp=" + timestamp)
                .toString();
    }

    public static final class Builder {
        private String version;
        private Long timestamp;

        private Builder() {}

        public static Builder aHeader() {
            return new Builder();
        }

        public Builder withVersion(String version) {
            this.version = version;
            return this;
        }

        public Builder withTimestamp(Long timestamp) {
            this.timestamp = timestamp;
            return this;
        }

        public Header build() {
            Header header = new Header();
            header.version = this.version;
            header.timestamp = this.timestamp;
            return header;
        }
    }
}
