package com.samsung.efota.zeus;

import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;

public class License {

    private static final String TYPE_STANDARD = "Standard";
    private static final String TYPE_TRIAL = "Trial";
    private static final String TYPE_ESP = "ESP";
    private static final String TYPE_EE = "EE";
    private String licenseKey;
    private String name;
    private String type;
    private Long quantity;
    private String startDate;
    private String endDate;
    private String description;
    private Long publishedAt;
    private List<String> macAddresses;

    private static void verifyLicense(License license) {

        if (license.getLicenseKey() == null
                || license.getName() == null
                || license.getType() == null
                || license.getQuantity() == null
                || license.getStartDate() == null
                || license.getEndDate() == null
                || license.getDescription() == null
                || license.getPublishedAt() == null
                || license.getMacAddresses() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        if (license.getLicenseKey().length() > 100) {
            throw new IllegalArgumentException("LicenseKey is over the max length(100).");
        }

        if (license.getName().length() > 45) {
            throw new IllegalArgumentException("Name is over the max length(45).");
        }

        if (!(TYPE_STANDARD.equals(license.getType())
                || TYPE_TRIAL.equals(license.getType())
                || TYPE_ESP.equals(license.getType())
                || TYPE_EE.equals(license.getType()))) {
            throw new IllegalArgumentException("Type is invalid");
        }
    }

    public String getLicenseKey() {
        return licenseKey;
    }

    public String getName() {
        return name;
    }

    public String getType() {
        return type;
    }

    public Long getQuantity() {
        return quantity;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public String getDescription() {
        return description;
    }

    public Long getPublishedAt() {
        return publishedAt;
    }

    public List<String> getMacAddresses() {
        return macAddresses;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof License)) return false;
        License license = (License) o;
        return Objects.equals(licenseKey, license.licenseKey)
                && Objects.equals(name, license.name)
                && Objects.equals(type, license.type)
                && Objects.equals(quantity, license.quantity)
                && Objects.equals(startDate, license.startDate)
                && Objects.equals(endDate, license.endDate)
                && Objects.equals(description, license.description)
                && Objects.equals(publishedAt, license.publishedAt)
                && Objects.equals(macAddresses, license.macAddresses);
    }

    @Override
    public int hashCode() {
        return Objects.hash(
                licenseKey,
                name,
                type,
                quantity,
                startDate,
                endDate,
                description,
                publishedAt,
                macAddresses);
    }

    @Override
    public String toString() {
        return new StringJoiner(", ", License.class.getSimpleName() + "[", "]")
                .add("licenseKey='" + licenseKey + "'")
                .add("name='" + name + "'")
                .add("type='" + type + "'")
                .add("quantity=" + quantity)
                .add("startDate='" + startDate + "'")
                .add("endDate='" + endDate + "'")
                .add("description='" + description + "'")
                .add("publishedAt=" + publishedAt)
                .add("macAddresses=" + macAddresses)
                .toString();
    }

    public static final class Builder {
        private String licenseKey;
        private String name;
        private String type;
        private Long quantity;
        private String startDate;
        private String endDate;
        private String description;
        private Long publishedAt;
        private List<String> macAddresses;

        private Builder() {}

        public static Builder aLicense() {
            return new Builder();
        }

        public Builder withLicenseKey(String licenseKey) {
            this.licenseKey = licenseKey;
            return this;
        }

        public Builder withName(String name) {
            this.name = name;
            return this;
        }

        public Builder withType(String type) {
            this.type = type;
            return this;
        }

        public Builder withQuantity(Long quantity) {
            this.quantity = quantity;
            return this;
        }

        public Builder withStartDate(String startDate) {
            this.startDate = startDate;
            return this;
        }

        public Builder withEndDate(String endDate) {
            this.endDate = endDate;
            return this;
        }

        public Builder withDescription(String description) {
            this.description = description;
            return this;
        }

        public Builder withPublishedAt(Long publishedAt) {
            this.publishedAt = publishedAt;
            return this;
        }

        public Builder withMacAddresses(List<String> macAddresses) {
            this.macAddresses = macAddresses;
            return this;
        }

        public License build() {
            License license = new License();
            license.type = this.type;
            license.endDate = this.endDate;
            license.description = this.description;
            license.name = this.name;
            license.licenseKey = this.licenseKey;
            license.startDate = this.startDate;
            license.publishedAt = this.publishedAt;
            license.quantity = this.quantity;
            license.macAddresses = this.macAddresses;
            return license;
        }
    }
}
