package com.samsung.efota.zeus;

import org.apache.commons.codec.binary.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;

public class LicenseCertificateCreator {

    private final String headerJson;
    private final String payloadJson;

    private LicenseCertificateCreator(String headerJson, String payloadJson) {
        this.headerJson = headerJson;
        this.payloadJson = payloadJson;
    }

    public static LicenseCertificateCreator.Builder init() {
        return new Builder();
    }

    private String sign(CertificateCipher cipher)
            throws NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException,
                    BadPaddingException, InvalidKeyException, SignatureException {
        byte[] headerBytes = headerJson.getBytes(StandardCharsets.UTF_8);
        byte[] payloadBytes = payloadJson.getBytes(StandardCharsets.UTF_8);

        String header =
                Base64.encodeBase64URLSafeString(headerJson.getBytes(StandardCharsets.UTF_8));
        String payload =
                Base64.encodeBase64URLSafeString(payloadJson.getBytes(StandardCharsets.UTF_8));

        byte[] signatureBytes = cipher.sign(headerBytes, payloadBytes);
        String signature = Base64.encodeBase64URLSafeString(signatureBytes);

        return String.format("%s.%s.%s", header, payload, signature);
    }

    public static final class Builder {
        private String headerJson;
        private String payloadJson;

        private Builder() {}

        public Builder withHeaderJson(String headerJson) {
            this.headerJson = headerJson;
            return this;
        }

        public Builder withPayloadJson(String payloadJson) {
            this.payloadJson = payloadJson;
            return this;
        }

        public String sign(CertificateCipher cipher)
                throws NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException,
                        BadPaddingException, InvalidKeyException, SignatureException {
            LicenseCertificateCreator licenseCertificateCreator =
                    new LicenseCertificateCreator(headerJson, payloadJson);
            return licenseCertificateCreator.sign(cipher);
        }
    }
}
