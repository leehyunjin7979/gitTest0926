package com.samsung.efota.zeus;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.binary.StringUtils;

import java.nio.charset.StandardCharsets;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;

public class LicenseCertificateDecoder {

    private final String[] parts;
    private final String headerJson;
    private final String payloadJson;
    private final byte[] signatureBytes;

    LicenseCertificateDecoder(String licenseCertificate) {
        parts = splitToken(licenseCertificate);

        headerJson = StringUtils.newStringUtf8(Base64.decodeBase64(parts[0]));
        payloadJson = StringUtils.newStringUtf8(Base64.decodeBase64(parts[1]));
        signatureBytes = Base64.decodeBase64(parts[2]);
    }

    private static String[] splitToken(String token) throws IllegalArgumentException {
        String[] parts = token.split("\\.");

        if (parts.length != 3) {
            throw new IllegalArgumentException(
                    String.format(
                            "The token was expected to have 2 parts, but got %s.", parts.length));
        }
        return parts;
    }

    public boolean verify(CertificateCipher cipher)
            throws NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        byte[] headerBytes = headerJson.getBytes(StandardCharsets.UTF_8);
        byte[] payloadBytes = payloadJson.getBytes(StandardCharsets.UTF_8);

        return cipher.verify(headerBytes, payloadBytes, signatureBytes);
    }

    public String getHeaderJson() {
        return headerJson;
    }

    public String getPayloadJson() {
        return payloadJson;
    }
}
