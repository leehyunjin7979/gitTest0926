package com.samsung.efota.zeus;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SignatureException;
import java.time.Instant;

public class LicenseCertificateUtil {

    private static final String VERSION = "1";

    private static final ObjectMapper OBJECT_MAPPER = new ObjectMapper();

    public static License toLicense(String base64PublicKey, String certificate)
            throws IOException, NoSuchAlgorithmException, InvalidKeyException, SignatureException {
        CertificateCipher cipher = new CertificateCipher(base64PublicKey, null);
        LicenseCertificateDecoder decoder = new LicenseCertificateDecoder(certificate);
        decoder.verify(cipher);

        Header header = OBJECT_MAPPER.readValue(decoder.getHeaderJson(), Header.class);
        if (verifyHeader(header) == false) {
            throw new IllegalArgumentException("Header is invalid.");
        }
        License license = OBJECT_MAPPER.readValue(decoder.getPayloadJson(), License.class);
        return license;
    }

    public static String toCertificate(String base64PrivateKey, License license)
            throws NoSuchPaddingException, NoSuchAlgorithmException, IllegalBlockSizeException,
                    BadPaddingException, InvalidKeyException, JsonProcessingException,
                    SignatureException {
        LicenseValidator.checkLicense(license);

        Header header =
                Header.Builder.aHeader()
                        .withVersion(VERSION)
                        .withTimestamp(Instant.now().toEpochMilli())
                        .build();

        CertificateCipher cipher = new CertificateCipher(null, base64PrivateKey);
        return LicenseCertificateCreator.init()
                .withHeaderJson(OBJECT_MAPPER.writeValueAsString(header))
                .withPayloadJson(OBJECT_MAPPER.writeValueAsString(license))
                .sign(cipher);
    }

    private static boolean verifyHeader(Header header) {
        return VERSION.equals(header.getVersion()) == true;
    }
}
