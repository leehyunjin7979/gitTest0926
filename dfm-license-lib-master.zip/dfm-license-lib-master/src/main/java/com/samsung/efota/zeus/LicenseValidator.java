package com.samsung.efota.zeus;

import java.sql.Timestamp;
import java.time.LocalDate;

public class LicenseValidator {

    private static final String TYPE_COMMERCIAL = "Commercial";
    private static final String TYPE_STANDARD = "Standard";
    private static final String TYPE_TRIAL = "Trial";
    private static final String TYPE_ESP = "ESP";
    private static final String TYPE_EE = "EE";
    private static final String TYPE_POC = "POC";

    public static void checkLicense(License license) {
        verifyLicenseKey(license);
        verifyName(license);
        verifyType(license);
        verifyQuantity(license);
        verifyStartDate(license);
        verifyEndDate(license);
        verifyDescription(license);
        verifyPublishedAt(license);
        verifyMacAddresses(license);
    }

    private static void verifyLicenseKey(License license) {
        if (license.getLicenseKey() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        if (license.getLicenseKey().length() > 100) {
            throw new IllegalArgumentException("LicenseKey is over the max length(100).");
        }
    }

    private static void verifyName(License license) {
        if (license.getName() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        if (license.getName().length() > 45) {
            throw new IllegalArgumentException("Name is over the max length(45).");
        }
    }

    private static void verifyType(License license) {
        if (license.getType() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        if (!(TYPE_COMMERCIAL.equals(license.getType())
                || TYPE_STANDARD.equals(license.getType())
                || TYPE_TRIAL.equals(license.getType())
                || TYPE_ESP.equals(license.getType())
                || TYPE_EE.equals(license.getType())
                || TYPE_POC.equals(license.getType()))
        ) {
            throw new IllegalArgumentException("Invalid type");
        }
    }

    private static void verifyQuantity(License license) {
        if (license.getQuantity() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        if (license.getQuantity() < 1) {
            throw new IllegalArgumentException("Quantity must be 1 or higher.");
        }
    }

    private static void verifyStartDate(License license) {
        if (license.getStartDate() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        LocalDate localDate = LocalDate.parse(license.getStartDate());
        if (localDate == null) {
            throw new IllegalArgumentException("Start date format is wrong.");
        }
    }

    private static void verifyEndDate(License license) {
        if (license.getEndDate() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        LocalDate startDate = LocalDate.parse(license.getStartDate());

        LocalDate endDate = LocalDate.parse(license.getEndDate());
        if (endDate == null) {
            throw new IllegalArgumentException("Start date format is wrong.");
        }

        if (startDate.isAfter(endDate) == true) {
            throw new IllegalArgumentException("endDate must be later than startDate");
        }
    }

    private static void verifyDescription(License license) {
        if (license.getDescription() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        if (license.getDescription().length() > 255) {
            throw new IllegalArgumentException("Description is over the max length(255).");
        }
    }

    private static void verifyPublishedAt(License license) {
        if (license.getPublishedAt() == null) {
            throw new NullPointerException("Field must not be null.");
        }

        Timestamp timestamp = new Timestamp(license.getPublishedAt());
        if (timestamp == null) {
            throw new IllegalArgumentException("Invalid timestamp format in PublishedAt");
        }
    }

    private static void verifyMacAddresses(License license) {
        // pass
    }
}
