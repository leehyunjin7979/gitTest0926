package com.samsung.efota.zeus;

public class ZeusLicenseException extends Exception {

}
