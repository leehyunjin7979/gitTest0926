package com.samsung.efota.zeus;

import org.apache.commons.codec.binary.Base64;
import org.junit.Test;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import java.io.IOException;
import java.security.*;
import java.time.LocalDate;
import java.util.Arrays;

import static org.junit.Assert.assertEquals;

public class LicenseCertificateUtilTest {

    @Test(expected = IllegalArgumentException.class)
    public void signAndVerify_whenWithGeneratorKeyWith0Quantity_shouldFail()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
            IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
            SignatureException {

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);

        KeyPair keyPair = keyPairGenerator.generateKeyPair();

        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        System.out.println("=PublicKey=");
        System.out.println(Base64.encodeBase64String(publicKey.getEncoded()));
        String base64PublicKey = Base64.encodeBase64String(publicKey.getEncoded());

        System.out.println("=PrivateKey=");
        System.out.println(Base64.encodeBase64String(privateKey.getEncoded()));
        String base64PrivateKey = Base64.encodeBase64String(privateKey.getEncoded());

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("Commercial")
                        .withDescription("Des")
                        .withName("12345")
                        .withQuantity(0L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        String certificate = LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
    }

    @Test
    public void signAndVerify_whenWithGeneratorKeyWith1Quantity_shouldSuccess()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
            IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
            SignatureException {

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);

        KeyPair keyPair = keyPairGenerator.generateKeyPair();

        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        System.out.println("=PublicKey=");
        System.out.println(Base64.encodeBase64String(publicKey.getEncoded()));
        String base64PublicKey = Base64.encodeBase64String(publicKey.getEncoded());

        System.out.println("=PrivateKey=");
        System.out.println(Base64.encodeBase64String(privateKey.getEncoded()));
        String base64PrivateKey = Base64.encodeBase64String(privateKey.getEncoded());

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("Commercial")
                        .withDescription("Des")
                        .withName("12345")
                        .withQuantity(1L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        String certificate = LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
        System.out.println(certificate);

        License licenseDecoded = LicenseCertificateUtil.toLicense(base64PublicKey, certificate);
        assertEquals(license, licenseDecoded);
    }

    @Test
    public void signAndVerify_whenWithGeneratorKey_shouldSuccess()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
                    IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
                    SignatureException {

        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance("RSA");
        keyPairGenerator.initialize(2048);

        KeyPair keyPair = keyPairGenerator.generateKeyPair();

        PublicKey publicKey = keyPair.getPublic();
        PrivateKey privateKey = keyPair.getPrivate();

        System.out.println("=PublicKey=");
        System.out.println(Base64.encodeBase64String(publicKey.getEncoded()));
        String base64PublicKey = Base64.encodeBase64String(publicKey.getEncoded());

        System.out.println("=PrivateKey=");
        System.out.println(Base64.encodeBase64String(privateKey.getEncoded()));
        String base64PrivateKey = Base64.encodeBase64String(privateKey.getEncoded());

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("Commercial")
                        .withDescription("Des")
                        .withName("12345")
                        .withQuantity(100L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        String certificate = LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
        System.out.println(certificate);

        License licenseDecoded = LicenseCertificateUtil.toLicense(base64PublicKey, certificate);
        assertEquals(license, licenseDecoded);
    }

    @Test
    public void signAndVerify_whenUsing2048LengthKey_shouldSuccess()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
                    IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
                    SignatureException {
        String base64PrivateKey =
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCOsBTmwnF+URnugbUwlYOTF/igFdGJNUkdIeZSbmveFH/oIWphUWYpYksZAeTjQ/Mx89VRByU94o+67Iyuh0pN1uc0Tz0eKIe23LufXPRdyTDdjzgmLW7Q1o2Ik2CSkHA/4lbZdUXCOF9m+2MPkNmAs4GYqHIaqXaP5vI62e21ZG2QYeSNbaEGrtvFkiMV/w4jksbr/54ZnSgbJDwyB17uvreOvR0mylQpQnelx3zAQ2zr64aFydUlFcOMfsnJp6YXE6lk82VDuuEIfQ5nQ5WiucssQ70AgVp+YECSAV4GMfC3d1/ii7fvaTVLlWx/E1HEbIkGLnUYAuhpjQZiklWdAgMBAAECggEAZkN4l3JgWQHTLgc0Tt+5byDNBh7dEBNqlUCIjCerk3zptvrL/XeTWrGh1QhwfRlkITb6eZo/bL0F+hgzM5qu/F67UdhAm2685agJqEu8r8LUDNbqjSIeu/opcer+Wcy/Rmn3iN7t4ib46RvegXd1CzKb/UcskENIQBZrIRazsT54oZHuVZ4zCLI6AlExNTTb17K+JWwSRR9pMdyBWoezePqr6APh1aBQ7bE2vkU1tq43KcbB1/7icPZJzHltj5RQ+Z/WXFgoq53BB5lvSb+ONx3RJA6Nk+L/f67Y+1mDMgqrs07hmEkpG/muNkFaPz9x+IIgl/XzvbWtfEFXnDhQmQKBgQDJASJPvegipt9+sPw7sFQSyFMxHjpMADdtiS8t8fHEnjLuy+DZUn811Kfi72zojC93ozIKACpbeouLVb8vkUpcxsR5kOiQVZc4obdZe1OM78KGwes7aqcj+6pMturKjKk/KCPQMYgqwSs3s/pcMQqt8jd5Ts1sNwdjn+vJATaKvwKBgQC1uk11T3gw/0G6hGWpGSJ1FILocK2+k0GzXmvEZ3krKy2WaF1wBduGuamLhqRrZGwiPPPOerJUtAIv6hP5AY6WL1Sl6ck/lSqeqOzjs1DBRl0AO6Y6sk+HPI2B/4xEQHWTTMwKWWmpFHU+nU8gpwRORg7cGgPvO0wDT5qzPV2CowKBgQC7LaArC9iw9B6p1tx8JP6VoxC9a72z6nuzOA3ERkry4rLhZuAS4Fzv3wEcNgOAJpNJYKKHZ5IKL/rknMv12uGZtctevU+koN+6b/XSkSLD2r2WSdzpLq9IteHnoGrShdxRoOqAxK9dyRaav7IDyfN8+lMoVva6sB/kaRbjzopg9wKBgCXXgK+v97hEPxym20CGIl29ArGCXTu1EFZYkBpa7almmVybqPFd1uPMH5kVVYGjbL0IckCJ3j6zKU1u8e/FOjrd6kOOVkDuP+zAAmw799H3ZABba3cHkHX5zwHGBCBmR9V/hXGWQuFZiDycp1CGVugxwIBmznDvqRl7Zxxx59n/AoGAOesZg5lqvtuI4zc1mXMffPvKgOf/t7hE7U8qt0KbdNixhkeQl99CtSPrz1PuigeuNxh/FbMIsH09Jypa9EFY3QBio7hF/EAKzSTlF5FlobMD5FvnJmUxfMG11rsZPFN4vD29DgQFuDFnkEVNDyaaLsYTi5WHpWB+rvgd1qVUytM=";

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("Commercial")
                        .withDescription("Des")
                        .withName("12345")
                        .withQuantity(100L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        String certificate = LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
        System.out.println(certificate);

        String base64PublicKey =
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjrAU5sJxflEZ7oG1MJWDkxf4oBXRiTVJHSHmUm5r3hR/6CFqYVFmKWJLGQHk40PzMfPVUQclPeKPuuyMrodKTdbnNE89HiiHtty7n1z0Xckw3Y84Ji1u0NaNiJNgkpBwP+JW2XVFwjhfZvtjD5DZgLOBmKhyGql2j+byOtnttWRtkGHkjW2hBq7bxZIjFf8OI5LG6/+eGZ0oGyQ8Mgde7r63jr0dJspUKUJ3pcd8wENs6+uGhcnVJRXDjH7JyaemFxOpZPNlQ7rhCH0OZ0OVornLLEO9AIFafmBAkgFeBjHwt3df4ou372k1S5VsfxNRxGyJBi51GALoaY0GYpJVnQIDAQAB";

        License licenseDecoded = LicenseCertificateUtil.toLicense(base64PublicKey, certificate);
        assertEquals(license, licenseDecoded);
    }

    @Test(expected = java.time.format.DateTimeParseException.class)
    public void signAndVerify_whenWrongDateFormat_shouldFail()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
                    IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
                    SignatureException {
        String base64PrivateKey =
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCOsBTmwnF+URnugbUwlYOTF/igFdGJNUkdIeZSbmveFH/oIWphUWYpYksZAeTjQ/Mx89VRByU94o+67Iyuh0pN1uc0Tz0eKIe23LufXPRdyTDdjzgmLW7Q1o2Ik2CSkHA/4lbZdUXCOF9m+2MPkNmAs4GYqHIaqXaP5vI62e21ZG2QYeSNbaEGrtvFkiMV/w4jksbr/54ZnSgbJDwyB17uvreOvR0mylQpQnelx3zAQ2zr64aFydUlFcOMfsnJp6YXE6lk82VDuuEIfQ5nQ5WiucssQ70AgVp+YECSAV4GMfC3d1/ii7fvaTVLlWx/E1HEbIkGLnUYAuhpjQZiklWdAgMBAAECggEAZkN4l3JgWQHTLgc0Tt+5byDNBh7dEBNqlUCIjCerk3zptvrL/XeTWrGh1QhwfRlkITb6eZo/bL0F+hgzM5qu/F67UdhAm2685agJqEu8r8LUDNbqjSIeu/opcer+Wcy/Rmn3iN7t4ib46RvegXd1CzKb/UcskENIQBZrIRazsT54oZHuVZ4zCLI6AlExNTTb17K+JWwSRR9pMdyBWoezePqr6APh1aBQ7bE2vkU1tq43KcbB1/7icPZJzHltj5RQ+Z/WXFgoq53BB5lvSb+ONx3RJA6Nk+L/f67Y+1mDMgqrs07hmEkpG/muNkFaPz9x+IIgl/XzvbWtfEFXnDhQmQKBgQDJASJPvegipt9+sPw7sFQSyFMxHjpMADdtiS8t8fHEnjLuy+DZUn811Kfi72zojC93ozIKACpbeouLVb8vkUpcxsR5kOiQVZc4obdZe1OM78KGwes7aqcj+6pMturKjKk/KCPQMYgqwSs3s/pcMQqt8jd5Ts1sNwdjn+vJATaKvwKBgQC1uk11T3gw/0G6hGWpGSJ1FILocK2+k0GzXmvEZ3krKy2WaF1wBduGuamLhqRrZGwiPPPOerJUtAIv6hP5AY6WL1Sl6ck/lSqeqOzjs1DBRl0AO6Y6sk+HPI2B/4xEQHWTTMwKWWmpFHU+nU8gpwRORg7cGgPvO0wDT5qzPV2CowKBgQC7LaArC9iw9B6p1tx8JP6VoxC9a72z6nuzOA3ERkry4rLhZuAS4Fzv3wEcNgOAJpNJYKKHZ5IKL/rknMv12uGZtctevU+koN+6b/XSkSLD2r2WSdzpLq9IteHnoGrShdxRoOqAxK9dyRaav7IDyfN8+lMoVva6sB/kaRbjzopg9wKBgCXXgK+v97hEPxym20CGIl29ArGCXTu1EFZYkBpa7almmVybqPFd1uPMH5kVVYGjbL0IckCJ3j6zKU1u8e/FOjrd6kOOVkDuP+zAAmw799H3ZABba3cHkHX5zwHGBCBmR9V/hXGWQuFZiDycp1CGVugxwIBmznDvqRl7Zxxx59n/AoGAOesZg5lqvtuI4zc1mXMffPvKgOf/t7hE7U8qt0KbdNixhkeQl99CtSPrz1PuigeuNxh/FbMIsH09Jypa9EFY3QBio7hF/EAKzSTlF5FlobMD5FvnJmUxfMG11rsZPFN4vD29DgQFuDFnkEVNDyaaLsYTi5WHpWB+rvgd1qVUytM=";
        String base64PublicKey =
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjrAU5sJxflEZ7oG1MJWDkxf4oBXRiTVJHSHmUm5r3hR/6CFqYVFmKWJLGQHk40PzMfPVUQclPeKPuuyMrodKTdbnNE89HiiHtty7n1z0Xckw3Y84Ji1u0NaNiJNgkpBwP+JW2XVFwjhfZvtjD5DZgLOBmKhyGql2j+byOtnttWRtkGHkjW2hBq7bxZIjFf8OI5LG6/+eGZ0oGyQ8Mgde7r63jr0dJspUKUJ3pcd8wENs6+uGhcnVJRXDjH7JyaemFxOpZPNlQ7rhCH0OZ0OVornLLEO9AIFafmBAkgFeBjHwt3df4ou372k1S5VsfxNRxGyJBi51GALoaY0GYpJVnQIDAQAB";

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("Commercial")
                        .withDescription("Des")
                        .withName("12345")
                        .withQuantity(100L)
                        .withStartDate("1982-02-121")
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
    }

    @Test(expected = IllegalArgumentException.class)
    public void signAndVerify_whenTooLongName_shouldFail()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
                    IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
                    SignatureException {
        String base64PrivateKey =
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCOsBTmwnF+URnugbUwlYOTF/igFdGJNUkdIeZSbmveFH/oIWphUWYpYksZAeTjQ/Mx89VRByU94o+67Iyuh0pN1uc0Tz0eKIe23LufXPRdyTDdjzgmLW7Q1o2Ik2CSkHA/4lbZdUXCOF9m+2MPkNmAs4GYqHIaqXaP5vI62e21ZG2QYeSNbaEGrtvFkiMV/w4jksbr/54ZnSgbJDwyB17uvreOvR0mylQpQnelx3zAQ2zr64aFydUlFcOMfsnJp6YXE6lk82VDuuEIfQ5nQ5WiucssQ70AgVp+YECSAV4GMfC3d1/ii7fvaTVLlWx/E1HEbIkGLnUYAuhpjQZiklWdAgMBAAECggEAZkN4l3JgWQHTLgc0Tt+5byDNBh7dEBNqlUCIjCerk3zptvrL/XeTWrGh1QhwfRlkITb6eZo/bL0F+hgzM5qu/F67UdhAm2685agJqEu8r8LUDNbqjSIeu/opcer+Wcy/Rmn3iN7t4ib46RvegXd1CzKb/UcskENIQBZrIRazsT54oZHuVZ4zCLI6AlExNTTb17K+JWwSRR9pMdyBWoezePqr6APh1aBQ7bE2vkU1tq43KcbB1/7icPZJzHltj5RQ+Z/WXFgoq53BB5lvSb+ONx3RJA6Nk+L/f67Y+1mDMgqrs07hmEkpG/muNkFaPz9x+IIgl/XzvbWtfEFXnDhQmQKBgQDJASJPvegipt9+sPw7sFQSyFMxHjpMADdtiS8t8fHEnjLuy+DZUn811Kfi72zojC93ozIKACpbeouLVb8vkUpcxsR5kOiQVZc4obdZe1OM78KGwes7aqcj+6pMturKjKk/KCPQMYgqwSs3s/pcMQqt8jd5Ts1sNwdjn+vJATaKvwKBgQC1uk11T3gw/0G6hGWpGSJ1FILocK2+k0GzXmvEZ3krKy2WaF1wBduGuamLhqRrZGwiPPPOerJUtAIv6hP5AY6WL1Sl6ck/lSqeqOzjs1DBRl0AO6Y6sk+HPI2B/4xEQHWTTMwKWWmpFHU+nU8gpwRORg7cGgPvO0wDT5qzPV2CowKBgQC7LaArC9iw9B6p1tx8JP6VoxC9a72z6nuzOA3ERkry4rLhZuAS4Fzv3wEcNgOAJpNJYKKHZ5IKL/rknMv12uGZtctevU+koN+6b/XSkSLD2r2WSdzpLq9IteHnoGrShdxRoOqAxK9dyRaav7IDyfN8+lMoVva6sB/kaRbjzopg9wKBgCXXgK+v97hEPxym20CGIl29ArGCXTu1EFZYkBpa7almmVybqPFd1uPMH5kVVYGjbL0IckCJ3j6zKU1u8e/FOjrd6kOOVkDuP+zAAmw799H3ZABba3cHkHX5zwHGBCBmR9V/hXGWQuFZiDycp1CGVugxwIBmznDvqRl7Zxxx59n/AoGAOesZg5lqvtuI4zc1mXMffPvKgOf/t7hE7U8qt0KbdNixhkeQl99CtSPrz1PuigeuNxh/FbMIsH09Jypa9EFY3QBio7hF/EAKzSTlF5FlobMD5FvnJmUxfMG11rsZPFN4vD29DgQFuDFnkEVNDyaaLsYTi5WHpWB+rvgd1qVUytM=";
        String base64PublicKey =
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjrAU5sJxflEZ7oG1MJWDkxf4oBXRiTVJHSHmUm5r3hR/6CFqYVFmKWJLGQHk40PzMfPVUQclPeKPuuyMrodKTdbnNE89HiiHtty7n1z0Xckw3Y84Ji1u0NaNiJNgkpBwP+JW2XVFwjhfZvtjD5DZgLOBmKhyGql2j+byOtnttWRtkGHkjW2hBq7bxZIjFf8OI5LG6/+eGZ0oGyQ8Mgde7r63jr0dJspUKUJ3pcd8wENs6+uGhcnVJRXDjH7JyaemFxOpZPNlQ7rhCH0OZ0OVornLLEO9AIFafmBAkgFeBjHwt3df4ou372k1S5VsfxNRxGyJBi51GALoaY0GYpJVnQIDAQAB";

        String name = "1234567890123456789012345678901234567890123456";

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("Commercial")
                        .withDescription("Des")
                        .withName(name)
                        .withQuantity(100L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
    }

    @Test(expected = IllegalArgumentException.class)
    public void signAndVerify_whenWrongType_shouldFail()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
            IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
            SignatureException {
        String base64PrivateKey =
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCOsBTmwnF+URnugbUwlYOTF/igFdGJNUkdIeZSbmveFH/oIWphUWYpYksZAeTjQ/Mx89VRByU94o+67Iyuh0pN1uc0Tz0eKIe23LufXPRdyTDdjzgmLW7Q1o2Ik2CSkHA/4lbZdUXCOF9m+2MPkNmAs4GYqHIaqXaP5vI62e21ZG2QYeSNbaEGrtvFkiMV/w4jksbr/54ZnSgbJDwyB17uvreOvR0mylQpQnelx3zAQ2zr64aFydUlFcOMfsnJp6YXE6lk82VDuuEIfQ5nQ5WiucssQ70AgVp+YECSAV4GMfC3d1/ii7fvaTVLlWx/E1HEbIkGLnUYAuhpjQZiklWdAgMBAAECggEAZkN4l3JgWQHTLgc0Tt+5byDNBh7dEBNqlUCIjCerk3zptvrL/XeTWrGh1QhwfRlkITb6eZo/bL0F+hgzM5qu/F67UdhAm2685agJqEu8r8LUDNbqjSIeu/opcer+Wcy/Rmn3iN7t4ib46RvegXd1CzKb/UcskENIQBZrIRazsT54oZHuVZ4zCLI6AlExNTTb17K+JWwSRR9pMdyBWoezePqr6APh1aBQ7bE2vkU1tq43KcbB1/7icPZJzHltj5RQ+Z/WXFgoq53BB5lvSb+ONx3RJA6Nk+L/f67Y+1mDMgqrs07hmEkpG/muNkFaPz9x+IIgl/XzvbWtfEFXnDhQmQKBgQDJASJPvegipt9+sPw7sFQSyFMxHjpMADdtiS8t8fHEnjLuy+DZUn811Kfi72zojC93ozIKACpbeouLVb8vkUpcxsR5kOiQVZc4obdZe1OM78KGwes7aqcj+6pMturKjKk/KCPQMYgqwSs3s/pcMQqt8jd5Ts1sNwdjn+vJATaKvwKBgQC1uk11T3gw/0G6hGWpGSJ1FILocK2+k0GzXmvEZ3krKy2WaF1wBduGuamLhqRrZGwiPPPOerJUtAIv6hP5AY6WL1Sl6ck/lSqeqOzjs1DBRl0AO6Y6sk+HPI2B/4xEQHWTTMwKWWmpFHU+nU8gpwRORg7cGgPvO0wDT5qzPV2CowKBgQC7LaArC9iw9B6p1tx8JP6VoxC9a72z6nuzOA3ERkry4rLhZuAS4Fzv3wEcNgOAJpNJYKKHZ5IKL/rknMv12uGZtctevU+koN+6b/XSkSLD2r2WSdzpLq9IteHnoGrShdxRoOqAxK9dyRaav7IDyfN8+lMoVva6sB/kaRbjzopg9wKBgCXXgK+v97hEPxym20CGIl29ArGCXTu1EFZYkBpa7almmVybqPFd1uPMH5kVVYGjbL0IckCJ3j6zKU1u8e/FOjrd6kOOVkDuP+zAAmw799H3ZABba3cHkHX5zwHGBCBmR9V/hXGWQuFZiDycp1CGVugxwIBmznDvqRl7Zxxx59n/AoGAOesZg5lqvtuI4zc1mXMffPvKgOf/t7hE7U8qt0KbdNixhkeQl99CtSPrz1PuigeuNxh/FbMIsH09Jypa9EFY3QBio7hF/EAKzSTlF5FlobMD5FvnJmUxfMG11rsZPFN4vD29DgQFuDFnkEVNDyaaLsYTi5WHpWB+rvgd1qVUytM=";
        String base64PublicKey =
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjrAU5sJxflEZ7oG1MJWDkxf4oBXRiTVJHSHmUm5r3hR/6CFqYVFmKWJLGQHk40PzMfPVUQclPeKPuuyMrodKTdbnNE89HiiHtty7n1z0Xckw3Y84Ji1u0NaNiJNgkpBwP+JW2XVFwjhfZvtjD5DZgLOBmKhyGql2j+byOtnttWRtkGHkjW2hBq7bxZIjFf8OI5LG6/+eGZ0oGyQ8Mgde7r63jr0dJspUKUJ3pcd8wENs6+uGhcnVJRXDjH7JyaemFxOpZPNlQ7rhCH0OZ0OVornLLEO9AIFafmBAkgFeBjHwt3df4ou372k1S5VsfxNRxGyJBi51GALoaY0GYpJVnQIDAQAB";

        String name = "Knox E-FOTA One On-Premise 1 Year Commercial";

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("AVC")
                        .withDescription("Des")
                        .withName(name)
                        .withQuantity(100L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
    }

    @Test
    public void signAndVerify_whenCommercialLicenseType_shouldSuccess()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
            IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
            SignatureException {
        String base64PrivateKey =
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCOsBTmwnF+URnugbUwlYOTF/igFdGJNUkdIeZSbmveFH/oIWphUWYpYksZAeTjQ/Mx89VRByU94o+67Iyuh0pN1uc0Tz0eKIe23LufXPRdyTDdjzgmLW7Q1o2Ik2CSkHA/4lbZdUXCOF9m+2MPkNmAs4GYqHIaqXaP5vI62e21ZG2QYeSNbaEGrtvFkiMV/w4jksbr/54ZnSgbJDwyB17uvreOvR0mylQpQnelx3zAQ2zr64aFydUlFcOMfsnJp6YXE6lk82VDuuEIfQ5nQ5WiucssQ70AgVp+YECSAV4GMfC3d1/ii7fvaTVLlWx/E1HEbIkGLnUYAuhpjQZiklWdAgMBAAECggEAZkN4l3JgWQHTLgc0Tt+5byDNBh7dEBNqlUCIjCerk3zptvrL/XeTWrGh1QhwfRlkITb6eZo/bL0F+hgzM5qu/F67UdhAm2685agJqEu8r8LUDNbqjSIeu/opcer+Wcy/Rmn3iN7t4ib46RvegXd1CzKb/UcskENIQBZrIRazsT54oZHuVZ4zCLI6AlExNTTb17K+JWwSRR9pMdyBWoezePqr6APh1aBQ7bE2vkU1tq43KcbB1/7icPZJzHltj5RQ+Z/WXFgoq53BB5lvSb+ONx3RJA6Nk+L/f67Y+1mDMgqrs07hmEkpG/muNkFaPz9x+IIgl/XzvbWtfEFXnDhQmQKBgQDJASJPvegipt9+sPw7sFQSyFMxHjpMADdtiS8t8fHEnjLuy+DZUn811Kfi72zojC93ozIKACpbeouLVb8vkUpcxsR5kOiQVZc4obdZe1OM78KGwes7aqcj+6pMturKjKk/KCPQMYgqwSs3s/pcMQqt8jd5Ts1sNwdjn+vJATaKvwKBgQC1uk11T3gw/0G6hGWpGSJ1FILocK2+k0GzXmvEZ3krKy2WaF1wBduGuamLhqRrZGwiPPPOerJUtAIv6hP5AY6WL1Sl6ck/lSqeqOzjs1DBRl0AO6Y6sk+HPI2B/4xEQHWTTMwKWWmpFHU+nU8gpwRORg7cGgPvO0wDT5qzPV2CowKBgQC7LaArC9iw9B6p1tx8JP6VoxC9a72z6nuzOA3ERkry4rLhZuAS4Fzv3wEcNgOAJpNJYKKHZ5IKL/rknMv12uGZtctevU+koN+6b/XSkSLD2r2WSdzpLq9IteHnoGrShdxRoOqAxK9dyRaav7IDyfN8+lMoVva6sB/kaRbjzopg9wKBgCXXgK+v97hEPxym20CGIl29ArGCXTu1EFZYkBpa7almmVybqPFd1uPMH5kVVYGjbL0IckCJ3j6zKU1u8e/FOjrd6kOOVkDuP+zAAmw799H3ZABba3cHkHX5zwHGBCBmR9V/hXGWQuFZiDycp1CGVugxwIBmznDvqRl7Zxxx59n/AoGAOesZg5lqvtuI4zc1mXMffPvKgOf/t7hE7U8qt0KbdNixhkeQl99CtSPrz1PuigeuNxh/FbMIsH09Jypa9EFY3QBio7hF/EAKzSTlF5FlobMD5FvnJmUxfMG11rsZPFN4vD29DgQFuDFnkEVNDyaaLsYTi5WHpWB+rvgd1qVUytM=";
        String base64PublicKey =
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjrAU5sJxflEZ7oG1MJWDkxf4oBXRiTVJHSHmUm5r3hR/6CFqYVFmKWJLGQHk40PzMfPVUQclPeKPuuyMrodKTdbnNE89HiiHtty7n1z0Xckw3Y84Ji1u0NaNiJNgkpBwP+JW2XVFwjhfZvtjD5DZgLOBmKhyGql2j+byOtnttWRtkGHkjW2hBq7bxZIjFf8OI5LG6/+eGZ0oGyQ8Mgde7r63jr0dJspUKUJ3pcd8wENs6+uGhcnVJRXDjH7JyaemFxOpZPNlQ7rhCH0OZ0OVornLLEO9AIFafmBAkgFeBjHwt3df4ou372k1S5VsfxNRxGyJBi51GALoaY0GYpJVnQIDAQAB";

        String name = "Knox E-FOTA One On-Premise 1 Year Commercial";

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("Commercial")
                        .withDescription(
                                "Knox E-FOTA One On-Premise 1 Year Commercial W/W L1+L2 Tech Support by Samsung")
                        .withName(name)
                        .withQuantity(100L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        String certificate = LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
        License licenseDecoded = LicenseCertificateUtil.toLicense(base64PublicKey, certificate);
        assertEquals(license, licenseDecoded);
    }

    @Test
    public void signAndVerify_whenPOCLicenseType_shouldSuccess()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
            IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
            SignatureException {
        String base64PrivateKey =
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCOsBTmwnF+URnugbUwlYOTF/igFdGJNUkdIeZSbmveFH/oIWphUWYpYksZAeTjQ/Mx89VRByU94o+67Iyuh0pN1uc0Tz0eKIe23LufXPRdyTDdjzgmLW7Q1o2Ik2CSkHA/4lbZdUXCOF9m+2MPkNmAs4GYqHIaqXaP5vI62e21ZG2QYeSNbaEGrtvFkiMV/w4jksbr/54ZnSgbJDwyB17uvreOvR0mylQpQnelx3zAQ2zr64aFydUlFcOMfsnJp6YXE6lk82VDuuEIfQ5nQ5WiucssQ70AgVp+YECSAV4GMfC3d1/ii7fvaTVLlWx/E1HEbIkGLnUYAuhpjQZiklWdAgMBAAECggEAZkN4l3JgWQHTLgc0Tt+5byDNBh7dEBNqlUCIjCerk3zptvrL/XeTWrGh1QhwfRlkITb6eZo/bL0F+hgzM5qu/F67UdhAm2685agJqEu8r8LUDNbqjSIeu/opcer+Wcy/Rmn3iN7t4ib46RvegXd1CzKb/UcskENIQBZrIRazsT54oZHuVZ4zCLI6AlExNTTb17K+JWwSRR9pMdyBWoezePqr6APh1aBQ7bE2vkU1tq43KcbB1/7icPZJzHltj5RQ+Z/WXFgoq53BB5lvSb+ONx3RJA6Nk+L/f67Y+1mDMgqrs07hmEkpG/muNkFaPz9x+IIgl/XzvbWtfEFXnDhQmQKBgQDJASJPvegipt9+sPw7sFQSyFMxHjpMADdtiS8t8fHEnjLuy+DZUn811Kfi72zojC93ozIKACpbeouLVb8vkUpcxsR5kOiQVZc4obdZe1OM78KGwes7aqcj+6pMturKjKk/KCPQMYgqwSs3s/pcMQqt8jd5Ts1sNwdjn+vJATaKvwKBgQC1uk11T3gw/0G6hGWpGSJ1FILocK2+k0GzXmvEZ3krKy2WaF1wBduGuamLhqRrZGwiPPPOerJUtAIv6hP5AY6WL1Sl6ck/lSqeqOzjs1DBRl0AO6Y6sk+HPI2B/4xEQHWTTMwKWWmpFHU+nU8gpwRORg7cGgPvO0wDT5qzPV2CowKBgQC7LaArC9iw9B6p1tx8JP6VoxC9a72z6nuzOA3ERkry4rLhZuAS4Fzv3wEcNgOAJpNJYKKHZ5IKL/rknMv12uGZtctevU+koN+6b/XSkSLD2r2WSdzpLq9IteHnoGrShdxRoOqAxK9dyRaav7IDyfN8+lMoVva6sB/kaRbjzopg9wKBgCXXgK+v97hEPxym20CGIl29ArGCXTu1EFZYkBpa7almmVybqPFd1uPMH5kVVYGjbL0IckCJ3j6zKU1u8e/FOjrd6kOOVkDuP+zAAmw799H3ZABba3cHkHX5zwHGBCBmR9V/hXGWQuFZiDycp1CGVugxwIBmznDvqRl7Zxxx59n/AoGAOesZg5lqvtuI4zc1mXMffPvKgOf/t7hE7U8qt0KbdNixhkeQl99CtSPrz1PuigeuNxh/FbMIsH09Jypa9EFY3QBio7hF/EAKzSTlF5FlobMD5FvnJmUxfMG11rsZPFN4vD29DgQFuDFnkEVNDyaaLsYTi5WHpWB+rvgd1qVUytM=";
        String base64PublicKey =
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjrAU5sJxflEZ7oG1MJWDkxf4oBXRiTVJHSHmUm5r3hR/6CFqYVFmKWJLGQHk40PzMfPVUQclPeKPuuyMrodKTdbnNE89HiiHtty7n1z0Xckw3Y84Ji1u0NaNiJNgkpBwP+JW2XVFwjhfZvtjD5DZgLOBmKhyGql2j+byOtnttWRtkGHkjW2hBq7bxZIjFf8OI5LG6/+eGZ0oGyQ8Mgde7r63jr0dJspUKUJ3pcd8wENs6+uGhcnVJRXDjH7JyaemFxOpZPNlQ7rhCH0OZ0OVornLLEO9AIFafmBAkgFeBjHwt3df4ou372k1S5VsfxNRxGyJBi51GALoaY0GYpJVnQIDAQAB";

        String name = "Knox E-FOTA One On-Premise 1 Year POC";

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("POC")
                        .withDescription(
                                "Knox E-FOTA One On-Premise 1 Year POC W/W L1+L2 Tech Support by Samsung")
                        .withName(name)
                        .withQuantity(100L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        String certificate = LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
        License licenseDecoded = LicenseCertificateUtil.toLicense(base64PublicKey, certificate);
        assertEquals(license, licenseDecoded);
    }

    @Test
    public void signAndVerify_whenTrialLicenseType_shouldSuccess()
            throws NoSuchPaddingException, IOException, NoSuchAlgorithmException,
            IllegalBlockSizeException, BadPaddingException, InvalidKeyException,
            SignatureException {
        String base64PrivateKey =
                "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCOsBTmwnF+URnugbUwlYOTF/igFdGJNUkdIeZSbmveFH/oIWphUWYpYksZAeTjQ/Mx89VRByU94o+67Iyuh0pN1uc0Tz0eKIe23LufXPRdyTDdjzgmLW7Q1o2Ik2CSkHA/4lbZdUXCOF9m+2MPkNmAs4GYqHIaqXaP5vI62e21ZG2QYeSNbaEGrtvFkiMV/w4jksbr/54ZnSgbJDwyB17uvreOvR0mylQpQnelx3zAQ2zr64aFydUlFcOMfsnJp6YXE6lk82VDuuEIfQ5nQ5WiucssQ70AgVp+YECSAV4GMfC3d1/ii7fvaTVLlWx/E1HEbIkGLnUYAuhpjQZiklWdAgMBAAECggEAZkN4l3JgWQHTLgc0Tt+5byDNBh7dEBNqlUCIjCerk3zptvrL/XeTWrGh1QhwfRlkITb6eZo/bL0F+hgzM5qu/F67UdhAm2685agJqEu8r8LUDNbqjSIeu/opcer+Wcy/Rmn3iN7t4ib46RvegXd1CzKb/UcskENIQBZrIRazsT54oZHuVZ4zCLI6AlExNTTb17K+JWwSRR9pMdyBWoezePqr6APh1aBQ7bE2vkU1tq43KcbB1/7icPZJzHltj5RQ+Z/WXFgoq53BB5lvSb+ONx3RJA6Nk+L/f67Y+1mDMgqrs07hmEkpG/muNkFaPz9x+IIgl/XzvbWtfEFXnDhQmQKBgQDJASJPvegipt9+sPw7sFQSyFMxHjpMADdtiS8t8fHEnjLuy+DZUn811Kfi72zojC93ozIKACpbeouLVb8vkUpcxsR5kOiQVZc4obdZe1OM78KGwes7aqcj+6pMturKjKk/KCPQMYgqwSs3s/pcMQqt8jd5Ts1sNwdjn+vJATaKvwKBgQC1uk11T3gw/0G6hGWpGSJ1FILocK2+k0GzXmvEZ3krKy2WaF1wBduGuamLhqRrZGwiPPPOerJUtAIv6hP5AY6WL1Sl6ck/lSqeqOzjs1DBRl0AO6Y6sk+HPI2B/4xEQHWTTMwKWWmpFHU+nU8gpwRORg7cGgPvO0wDT5qzPV2CowKBgQC7LaArC9iw9B6p1tx8JP6VoxC9a72z6nuzOA3ERkry4rLhZuAS4Fzv3wEcNgOAJpNJYKKHZ5IKL/rknMv12uGZtctevU+koN+6b/XSkSLD2r2WSdzpLq9IteHnoGrShdxRoOqAxK9dyRaav7IDyfN8+lMoVva6sB/kaRbjzopg9wKBgCXXgK+v97hEPxym20CGIl29ArGCXTu1EFZYkBpa7almmVybqPFd1uPMH5kVVYGjbL0IckCJ3j6zKU1u8e/FOjrd6kOOVkDuP+zAAmw799H3ZABba3cHkHX5zwHGBCBmR9V/hXGWQuFZiDycp1CGVugxwIBmznDvqRl7Zxxx59n/AoGAOesZg5lqvtuI4zc1mXMffPvKgOf/t7hE7U8qt0KbdNixhkeQl99CtSPrz1PuigeuNxh/FbMIsH09Jypa9EFY3QBio7hF/EAKzSTlF5FlobMD5FvnJmUxfMG11rsZPFN4vD29DgQFuDFnkEVNDyaaLsYTi5WHpWB+rvgd1qVUytM=";
        String base64PublicKey =
                "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAjrAU5sJxflEZ7oG1MJWDkxf4oBXRiTVJHSHmUm5r3hR/6CFqYVFmKWJLGQHk40PzMfPVUQclPeKPuuyMrodKTdbnNE89HiiHtty7n1z0Xckw3Y84Ji1u0NaNiJNgkpBwP+JW2XVFwjhfZvtjD5DZgLOBmKhyGql2j+byOtnttWRtkGHkjW2hBq7bxZIjFf8OI5LG6/+eGZ0oGyQ8Mgde7r63jr0dJspUKUJ3pcd8wENs6+uGhcnVJRXDjH7JyaemFxOpZPNlQ7rhCH0OZ0OVornLLEO9AIFafmBAkgFeBjHwt3df4ou372k1S5VsfxNRxGyJBi51GALoaY0GYpJVnQIDAQAB";

        String name = "Knox E-FOTA One On-Premise 6 Months Trial";

        License license =
                License.Builder.aLicense()
                        .withLicenseKey("ABCD-EFT")
                        .withType("POC")
                        .withDescription(
                                "Knox E-FOTA One On-Premise 6 Months Trial W/W")
                        .withName(name)
                        .withQuantity(100L)
                        .withStartDate(LocalDate.now().toString())
                        .withEndDate(LocalDate.now().plusMonths(1).toString())
                        .withPublishedAt(System.currentTimeMillis())
                        .withMacAddresses(Arrays.asList("abcd", "sfaa"))
                        .build();

        System.out.println("=LicensePrivateKey=");
        String certificate = LicenseCertificateUtil.toCertificate(base64PrivateKey, license);
        License licenseDecoded = LicenseCertificateUtil.toLicense(base64PublicKey, certificate);
        assertEquals(license, licenseDecoded);
    }
}
